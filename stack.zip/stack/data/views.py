from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import class_table

# Create your views here.

def class_home(request):
    return render(request,'class_home.html')

def class_8(request):
    return render(request,'class_8.html')
def class_9(request):
    return render(request,'class_9.html')
def class_10(request):
    return render(request,'class_10.html')
def class_11(request):
    return render(request,'class_11.html')
def class_12(request):
    return render(request,'class_12.html')

def register (request):
    return render(request,'register.html')
def reg(request):
    name = request.GET['name']
    email = request.GET['email']
    pwd = request.GET['pwd']
    ph_no = request.GET['ph_no']

    if class_table.objects.filter(email=email).exists():
        return render(request,'login.html')
    new_user = class_table(name = name ,email = email,pwd = pwd,ph_no = ph_no)
    new_user.save()

    return redirect(request,'login.html')

def login(request):
    return render(request,'login.html')
def do_login(request):
    if request.method == "POST":
        email = request.POST.get('email')  # Use get() to avoid errors
        pwd = request.POST.get('pwd')

        if not email or not pwd:
            return HttpResponse("Email and Password are required.")

        try:
            user = class_table.objects.get(email=email, pwd=pwd)
            return redirect('class_home')
        except class_table.DoesNotExist:
            return HttpResponse("Invalid Email or Password.")
    else:
        return HttpResponse("Invalid request method.")

def class_8(request):
    return render(request,'class_8.html')
def class_9(request):
    return render(request,'class_9.html')
def class_10(request):
    return render(request,'class_10.html')
def class_11(request):
    return render(request,'class_11.html')
def class_12(request):
    return render(request,'class_12.html')
from django.urls import path
from . import views

urlpatterns = [
    path('class_home', views.class_home, name='class_home'),
    path('class_8', views.class_8, name='class_8'),
    path('class_9', views.class_9, name='class_9'),
    path('class_10', views.class_10, name='class_10'),
    path('class_11', views.class_11, name='class_11'),
    path('class_12', views.class_12, name='class_12'),

    path('register',views.register,name = 'register'),
    path('reg',views.reg,name = 'reg'),

    path('login',views.login,name = 'login'),
    path('do_login',views.do_login,name = 'do_login'),

    path('class_8', views.class_8, name='class_8'),
    path('class_9', views.class_9, name='class_9'),
    path('class_10', views.class_10, name='class_10'),
    path('class_11', views.class_11, name='class_11'),
    path('class_12', views.class_12, name='class_12'),
]
